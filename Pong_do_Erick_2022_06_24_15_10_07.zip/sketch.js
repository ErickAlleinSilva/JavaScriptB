//variáveis da bolinha

let xBolinha = 300;
let yBolinha = 200;
let diameter = 30;
let raio = diameter / 2;
let xVelocidadeBolinha = 6;
let yVelocidadeBolinha = 6;
let alturaRect = 50;

//variáveis da raquete

let xRaquete = 5;
let yRaquete = 150;
let raqueteComprimento = 10;
let raqueteAltura = 90;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  mostraBolinha();
  movimentaBolinha();
  CheckEdgeCollision();
  mostraRaquete();
  movimentaMinhaRaquete();
  CheckRaqueteCollision();
}

function mostraBolinha() {
  circle (xBolinha, yBolinha, diameter);
}

function movimentaBolinha() {
  xBolinha += xVelocidadeBolinha;
  yBolinha += yVelocidadeBolinha;
}

function CheckEdgeCollision() {
  if (xBolinha + raio > width || xBolinha - raio < 0) {xVelocidadeBolinha *= -1}
  if (yBolinha + raio > height || yBolinha - raio < 0) {yVelocidadeBolinha *= -1}
}

function mostraRaquete() {
  rect(xRaquete, yRaquete, raqueteComprimento, raqueteAltura);
}

function movimentaMinhaRaquete() {
  if (keyIsDown(UP_ARROW)) {yRaquete -= 10}
  if (keyIsDown(DOWN_ARROW)) {yRaquete += 10}
}

function CheckRaqueteCollision() {
  if (xBolinha - raio < xRaquete + raqueteComprimento && yBolinha - raio < yRaquete + raqueteAltura && yBolinha + raio > yRaquete) {
    xVelocidadeBolinha *= -1}
}